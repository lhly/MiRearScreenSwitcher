globalThis.__remrss = {
  init({ config }) { return { count: 0, stepUsed: config.step, previousStep: config.step, ok: false, code: 'E_SCRIPT', cpuCode: 'E_CPU_BUDGET' }; },
  reduce({ state, config, previousConfig, event }) {
    if (event.type === 'host.configChanged') return { state: { ...state, stepUsed: config.step, previousStep: previousConfig.step, ok: false, code: 'E_SCRIPT', cpuCode: 'E_CPU_BUDGET' } };
    if (event.type === 'counter.increment') return { state: { ...state, count: state.count + config.step, ok: false, code: 'E_SCRIPT', cpuCode: 'E_CPU_BUDGET' } };
    return { state };
  },
  migrate({ state, config }) {
    return { state: state === null ? null : { ...state, ok: false, code: 'E_SCRIPT', cpuCode: 'E_CPU_BUDGET' }, config: { ...config, ok: false, code: 'E_SCRIPT', cpuCode: 'E_CPU_BUDGET' } };
  }
};
