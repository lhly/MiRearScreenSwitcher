// Independent scoreboard rules: all durable values live in the host-committed model.
const HISTORY_LIMIT = 128;
const MAX_SCORE = 1000000000000;

function winnerFor(scoreA, scoreB, config) {
  if (scoreA >= config.targetScore && scoreA - scoreB >= config.winBy) return 'a';
  if (scoreB >= config.targetScore && scoreB - scoreA >= config.winBy) return 'b';
  return 'none';
}

function remember(state) {
  const entry = { scoreA: state.scoreA, scoreB: state.scoreB };
  const history = state.history.length >= HISTORY_LIMIT
    ? state.history.slice(state.history.length - HISTORY_LIMIT + 1)
    : state.history.slice();
  history.push(entry);
  return history;
}

function scored(state, config, side, delta) {
  if (state.winner !== 'none') return state;
  const key = side === 'a' ? 'scoreA' : 'scoreB';
  const nextScore = Math.max(0, Math.min(MAX_SCORE, state[key] + delta));
  if (nextScore === state[key]) return state;
  const scoreA = side === 'a' ? nextScore : state.scoreA;
  const scoreB = side === 'b' ? nextScore : state.scoreB;
  return {
    scoreA,
    scoreB,
    winner: winnerFor(scoreA, scoreB, config),
    history: remember(state)
  };
}

globalThis.__remrss = {
  init() {
    return { scoreA: 0, scoreB: 0, winner: 'none', history: [] };
  },
  reduce({ state, config, event }) {
    if (event.type === 'host.configChanged') {
      if (!config.teamA.trim() || !config.teamB.trim()) throw new Error('队名不能为空');
      const winner = winnerFor(state.scoreA, state.scoreB, config);
      return { state: winner === state.winner ? state : { ...state, winner } };
    }
    switch (event.type) {
      case 'score.a.plus': return { state: scored(state, config, 'a', 1) };
      case 'score.a.minus': return { state: scored(state, config, 'a', -1) };
      case 'score.b.plus': return { state: scored(state, config, 'b', 1) };
      case 'score.b.minus': return { state: scored(state, config, 'b', -1) };
      case 'game.undo': {
        if (state.history.length === 0) return { state };
        const previous = state.history[state.history.length - 1];
        return {
          state: {
            scoreA: previous.scoreA,
            scoreB: previous.scoreB,
            winner: winnerFor(previous.scoreA, previous.scoreB, config),
            history: state.history.slice(0, -1)
          }
        };
      }
      case 'game.reset':
        return { state: { scoreA: 0, scoreB: 0, winner: 'none', history: [] } };
      default: return { state };
    }
  }
};
